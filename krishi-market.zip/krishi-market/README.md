# 🌾 Krishi Market — Farmer-to-Consumer Agri Marketplace

A web platform that directly connects local farmers with end consumers, enabling direct sales of fresh produce, dairy, and organic products.

---

## 📁 Project Structure

```
krishi-market/
├── frontend/          # React.js (Vite) frontend
│   └── src/
│       ├── components/
│       │   ├── Farmer/
│       │   ├── Consumer/
│       │   ├── Admin/
│       │   └── Common/
│       ├── pages/
│       ├── context/
│       ├── hooks/
│       ├── utils/
│       └── styles/
└── backend/           # Node.js + Express API
    ├── routes/
    ├── controllers/
    ├── models/
    ├── middleware/
    └── config/
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js v18+
- npm v9+
- MongoDB (local or Atlas)

---

## 🖥️ Frontend Setup

```bash
cd frontend
npm install
npm run dev
```
Runs on: http://localhost:5173

---

## ⚙️ Backend Setup

```bash
cd backend
npm install
npm run dev
```
Runs on: http://localhost:5000

---

## 🌐 Environment Variables

### Backend — create `backend/.env`:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/krishimarket
JWT_SECRET=your_jwt_secret_key
NODE_ENV=development
```

### Frontend — create `frontend/.env`:
```
VITE_API_URL=http://localhost:5000/api
```

---

## 🧑‍💻 User Roles
| Role     | Access |
|----------|--------|
| Farmer   | Register, list products, manage orders |
| Consumer | Browse, order, track, rate |
| Admin    | Approve farmers, monitor platform |

---

## 🛠 Tech Stack
- **Frontend**: React.js (Vite), Tailwind CSS, React Router
- **Backend**: Node.js, Express.js, REST API
- **Database**: MongoDB + Mongoose
- **Auth**: JWT

---

## 📦 Building for Production

```bash
# Frontend
cd frontend && npm run build

# Backend
cd backend && npm start
```
