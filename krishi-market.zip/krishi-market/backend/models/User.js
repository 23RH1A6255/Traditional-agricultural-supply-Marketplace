const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['farmer', 'consumer', 'admin'], default: 'consumer' },

  // Farmer-specific
  farmLocation: String,
  cropTypes: [String],
  farmingMethod: { type: String, enum: ['organic', 'conventional', 'mixed'] },
  isVerified: { type: Boolean, default: false },
  bio: String,

  // Consumer-specific
  address: String,
  phone: String,

  createdAt: { type: Date, default: Date.now }
});

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
