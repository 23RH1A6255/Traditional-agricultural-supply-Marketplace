const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  farmer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  category: {
    type: String,
    enum: ['vegetables', 'fruits', 'dairy', 'grains', 'organic', 'other'],
    required: true
  },
  description: String,
  price: { type: Number, required: true },
  unit: { type: String, default: 'kg' },
  availableQuantity: { type: Number, required: true },
  isOrganic: { type: Boolean, default: false },
  harvestDate: Date,
  image: { type: String, default: '' },
  isAvailable: { type: Boolean, default: true },
  ratings: [
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      rating: { type: Number, min: 1, max: 5 },
      review: String
    }
  ],
  createdAt: { type: Date, default: Date.now }
});

productSchema.virtual('averageRating').get(function () {
  if (this.ratings.length === 0) return 0;
  return this.ratings.reduce((acc, r) => acc + r.rating, 0) / this.ratings.length;
});

module.exports = mongoose.model('Product', productSchema);
