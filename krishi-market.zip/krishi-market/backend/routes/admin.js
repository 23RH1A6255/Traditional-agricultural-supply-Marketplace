const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const { protect, authorize } = require('../middleware/auth');

// GET /api/admin/farmers — all pending farmers
router.get('/farmers', protect, authorize('admin'), async (req, res) => {
  try {
    const farmers = await User.find({ role: 'farmer' }).select('-password');
    res.json(farmers);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/admin/farmers/:id/verify — approve farmer
router.put('/farmers/:id/verify', protect, authorize('admin'), async (req, res) => {
  try {
    const farmer = await User.findByIdAndUpdate(req.params.id, { isVerified: true }, { new: true }).select('-password');
    res.json(farmer);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/admin/analytics
router.get('/analytics', protect, authorize('admin'), async (req, res) => {
  try {
    const totalFarmers = await User.countDocuments({ role: 'farmer', isVerified: true });
    const totalConsumers = await User.countDocuments({ role: 'consumer' });
    const totalOrders = await Order.countDocuments();
    const totalProducts = await Product.countDocuments({ isAvailable: true });
    const pendingApprovals = await User.countDocuments({ role: 'farmer', isVerified: false });

    res.json({ totalFarmers, totalConsumers, totalOrders, totalProducts, pendingApprovals });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
