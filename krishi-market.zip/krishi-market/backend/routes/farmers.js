const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect } = require('../middleware/auth');

// GET /api/farmers — list all verified farmers
router.get('/', async (req, res) => {
  try {
    const farmers = await User.find({ role: 'farmer', isVerified: true }).select('-password');
    res.json(farmers);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/farmers/:id — get a single farmer profile
router.get('/:id', async (req, res) => {
  try {
    const farmer = await User.findById(req.params.id).select('-password');
    if (!farmer || farmer.role !== 'farmer') return res.status(404).json({ message: 'Farmer not found' });
    res.json(farmer);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/farmers/profile — update farmer profile
router.put('/profile', protect, async (req, res) => {
  try {
    const { farmLocation, cropTypes, farmingMethod, bio, phone } = req.body;
    const user = await User.findByIdAndUpdate(req.user._id, { farmLocation, cropTypes, farmingMethod, bio, phone }, { new: true }).select('-password');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
