const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { protect, authorize } = require('../middleware/auth');

// GET /api/products — browse with filters
router.get('/', async (req, res) => {
  try {
    const { category, isOrganic, farmer, search } = req.query;
    const query = { isAvailable: true };
    if (category) query.category = category;
    if (isOrganic) query.isOrganic = isOrganic === 'true';
    if (farmer) query.farmer = farmer;
    if (search) query.name = { $regex: search, $options: 'i' };

    const products = await Product.find(query).populate('farmer', 'name farmLocation farmingMethod');
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('farmer', 'name farmLocation farmingMethod bio');
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/products — farmer creates product
router.post('/', protect, authorize('farmer'), async (req, res) => {
  try {
    const product = await Product.create({ ...req.body, farmer: req.user._id });
    res.status(201).json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/products/:id — farmer updates product
router.put('/:id', protect, authorize('farmer'), async (req, res) => {
  try {
    const product = await Product.findOneAndUpdate(
      { _id: req.params.id, farmer: req.user._id },
      req.body,
      { new: true }
    );
    if (!product) return res.status(404).json({ message: 'Product not found or unauthorized' });
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/products/:id
router.delete('/:id', protect, authorize('farmer'), async (req, res) => {
  try {
    await Product.findOneAndDelete({ _id: req.params.id, farmer: req.user._id });
    res.json({ message: 'Product removed' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/products/:id/rate — consumer rates product
router.post('/:id/rate', protect, authorize('consumer'), async (req, res) => {
  try {
    const { rating, review } = req.body;
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    product.ratings.push({ user: req.user._id, rating, review });
    await product.save();
    res.json({ message: 'Rating added' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
