const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const { protect, authorize } = require('../middleware/auth');

// POST /api/orders — consumer places order
router.post('/', protect, authorize('consumer'), async (req, res) => {
  try {
    const order = await Order.create({ ...req.body, consumer: req.user._id });
    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/orders/my — consumer's order history
router.get('/my', protect, async (req, res) => {
  try {
    const orders = await Order.find({ consumer: req.user._id })
      .populate('items.product', 'name image')
      .populate('items.farmer', 'name')
      .sort('-createdAt');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/orders/farmer — farmer sees their orders
router.get('/farmer', protect, authorize('farmer'), async (req, res) => {
  try {
    const orders = await Order.find({ 'items.farmer': req.user._id })
      .populate('consumer', 'name phone address')
      .populate('items.product', 'name')
      .sort('-createdAt');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/orders/:id/status — farmer or admin updates status
router.put('/:id/status', protect, async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true }
    );
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
