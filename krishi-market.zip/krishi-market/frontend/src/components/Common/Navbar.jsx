import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <nav className="bg-primary text-white px-6 py-4 flex items-center justify-between shadow-lg">
      <Link to="/" className="text-2xl font-bold tracking-tight flex items-center gap-2">
        🌾 Krishi Market
      </Link>
      <div className="flex items-center gap-4 text-sm font-medium">
        <Link to="/products" className="hover:text-light transition">Shop</Link>
        <Link to="/farmers" className="hover:text-light transition">Farmers</Link>

        {!user ? (
          <>
            <Link to="/login" className="hover:text-light transition">Login</Link>
            <Link to="/register" className="bg-accent text-white px-4 py-1.5 rounded-lg hover:opacity-90 transition">
              Register
            </Link>
          </>
        ) : (
          <>
            {user.role === 'farmer' && (
              <Link to="/dashboard/farmer" className="hover:text-light transition">Dashboard</Link>
            )}
            {user.role === 'consumer' && (
              <Link to="/dashboard/consumer" className="hover:text-light transition">My Orders</Link>
            )}
            {user.role === 'admin' && (
              <Link to="/dashboard/admin" className="hover:text-light transition">Admin</Link>
            )}
            <span className="text-light text-xs">Hi, {user.name.split(' ')[0]}</span>
            <button onClick={handleLogout} className="bg-red-500 px-3 py-1.5 rounded-lg hover:bg-red-600 transition">
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  )
}
