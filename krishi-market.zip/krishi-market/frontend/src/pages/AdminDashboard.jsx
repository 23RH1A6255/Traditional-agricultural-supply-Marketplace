import { useEffect, useState } from 'react'
import api from '../utils/api'

export default function AdminDashboard() {
  const [farmers, setFarmers] = useState([])
  const [analytics, setAnalytics] = useState(null)

  useEffect(() => {
    api.get('/admin/farmers').then(r => setFarmers(r.data))
    api.get('/admin/analytics').then(r => setAnalytics(r.data))
  }, [])

  const verifyFarmer = async (id) => {
    await api.put(`/admin/farmers/${id}/verify`)
    setFarmers(farmers.map(f => f._id === id ? { ...f, isVerified: true } : f))
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-primary mb-6">Admin Dashboard ⚙️</h1>

      {/* Analytics */}
      {analytics && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {[
            { label: 'Farmers', val: analytics.totalFarmers, icon: '🚜' },
            { label: 'Consumers', val: analytics.totalConsumers, icon: '👥' },
            { label: 'Orders', val: analytics.totalOrders, icon: '📦' },
            { label: 'Products', val: analytics.totalProducts, icon: '🌾' },
            { label: 'Pending', val: analytics.pendingApprovals, icon: '⏳' },
          ].map(({ label, val, icon }) => (
            <div key={label} className="card text-center">
              <div className="text-3xl">{icon}</div>
              <div className="text-2xl font-bold text-primary">{val}</div>
              <div className="text-xs text-gray-500">{label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Farmer Verification */}
      <h2 className="text-xl font-bold mb-4">Farmer Verification</h2>
      <div className="space-y-3">
        {farmers.map(f => (
          <div key={f._id} className="card flex justify-between items-center">
            <div>
              <p className="font-semibold">{f.name}</p>
              <p className="text-sm text-gray-500">{f.email} · {f.farmLocation}</p>
              <p className="text-xs text-gray-400">{f.cropTypes?.join(', ')} · {f.farmingMethod}</p>
            </div>
            {f.isVerified ? (
              <span className="badge-status bg-green-100 text-green-700">✓ Verified</span>
            ) : (
              <button onClick={() => verifyFarmer(f._id)} className="btn-primary text-sm px-4 py-1.5">
                Approve
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
