import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../utils/api'

export default function Farmers() {
  const [farmers, setFarmers] = useState([])

  useEffect(() => {
    api.get('/farmers').then(r => setFarmers(r.data))
  }, [])

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-primary mb-6">Our Farmers 🚜</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {farmers.map(f => (
          <Link key={f._id} to={`/products?farmer=${f._id}`} className="card hover:shadow-xl hover:-translate-y-1 transition-all">
            <div className="w-16 h-16 rounded-full bg-light flex items-center justify-center text-3xl mb-3">🧑‍🌾</div>
            <h3 className="font-bold text-gray-800">{f.name}</h3>
            <p className="text-sm text-gray-500 mt-1">📍 {f.farmLocation}</p>
            {f.farmingMethod && (
              <span className={`mt-2 inline-block text-xs font-semibold px-2 py-0.5 rounded-full ${f.farmingMethod === 'organic' ? 'bg-light text-primary' : 'bg-gray-100 text-gray-600'}`}>
                {f.farmingMethod}
              </span>
            )}
            <p className="text-xs text-gray-400 mt-2">{f.cropTypes?.join(', ')}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
