import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary to-secondary text-white py-20 px-6 text-center">
        <h1 className="text-5xl font-bold mb-4">Farm Fresh, Direct to You</h1>
        <p className="text-xl text-light mb-8 max-w-xl mx-auto">
          Connect directly with local farmers. Get fresh vegetables, fruits, dairy and organic produce — no middlemen.
        </p>
        <div className="flex justify-center gap-4">
          <Link to="/products" className="bg-accent text-white px-8 py-3 rounded-xl font-bold text-lg hover:opacity-90 transition">
            Shop Now
          </Link>
          <Link to="/register?role=farmer" className="border-2 border-white text-white px-8 py-3 rounded-xl font-bold text-lg hover:bg-white hover:text-primary transition">
            Sell as Farmer
          </Link>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10 text-primary">Browse by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Vegetables', emoji: '🥦', cat: 'vegetables' },
            { label: 'Fruits', emoji: '🍎', cat: 'fruits' },
            { label: 'Dairy', emoji: '🥛', cat: 'dairy' },
            { label: 'Grains', emoji: '🌾', cat: 'grains' },
          ].map(({ label, emoji, cat }) => (
            <Link
              key={cat}
              to={`/products?category=${cat}`}
              className="card text-center hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer"
            >
              <div className="text-5xl mb-3">{emoji}</div>
              <p className="font-semibold text-lg text-primary">{label}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Why Krishi Market */}
      <section className="bg-light py-16 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-10 text-primary">Why Krishi Market?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: '🚜', title: 'Support Local Farmers', desc: 'Farmers earn more by cutting out intermediaries.' },
              { icon: '🌱', title: 'Fresh & Organic', desc: 'Produce harvested and delivered with full traceability.' },
              { icon: '💰', title: 'Fair Prices', desc: 'Better prices for both farmers and consumers.' },
            ].map(({ icon, title, desc }) => (
              <div key={title} className="card">
                <div className="text-4xl mb-3">{icon}</div>
                <h3 className="font-bold text-xl text-primary mb-2">{title}</h3>
                <p className="text-gray-600">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
