import { useEffect, useState } from 'react'
import api from '../utils/api'

const statusColor = {
  pending: 'bg-yellow-100 text-yellow-700',
  confirmed: 'bg-blue-100 text-blue-700',
  dispatched: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700'
}

export default function ConsumerDashboard() {
  const [orders, setOrders] = useState([])

  useEffect(() => {
    api.get('/orders/my').then(r => setOrders(r.data))
  }, [])

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-primary mb-6">My Orders 🛒</h1>
      {orders.length === 0 ? (
        <p className="text-gray-400 text-center py-20">No orders yet. Start shopping!</p>
      ) : (
        <div className="space-y-4">
          {orders.map(o => (
            <div key={o._id} className="card">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold">Order #{o._id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm text-gray-500">{new Date(o.createdAt).toLocaleDateString()}</p>
                </div>
                <span className={`badge-status ${statusColor[o.status]}`}>{o.status}</span>
              </div>
              <div className="mt-3 space-y-1">
                {o.items?.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm text-gray-600">
                    <span>{item.product?.name} × {item.quantity}</span>
                    <span>₹{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>
              <div className="mt-3 pt-3 border-t flex justify-between font-semibold">
                <span>Total</span>
                <span className="text-primary">₹{o.totalAmount}</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">📦 Deliver to: {o.deliveryAddress}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
