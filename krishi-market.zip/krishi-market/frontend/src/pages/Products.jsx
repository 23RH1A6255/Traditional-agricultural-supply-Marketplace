import { useEffect, useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import api from '../utils/api'

export default function Products() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchParams, setSearchParams] = useSearchParams()
  const [search, setSearch] = useState('')

  const category = searchParams.get('category') || ''
  const isOrganic = searchParams.get('isOrganic') || ''

  useEffect(() => {
    const fetch = async () => {
      setLoading(true)
      try {
        const params = new URLSearchParams()
        if (category) params.append('category', category)
        if (isOrganic) params.append('isOrganic', isOrganic)
        if (search) params.append('search', search)
        const { data } = await api.get(`/products?${params}`)
        setProducts(data)
      } catch (err) {
        console.error(err)
      }
      setLoading(false)
    }
    fetch()
  }, [category, isOrganic, search])

  const categories = ['', 'vegetables', 'fruits', 'dairy', 'grains', 'organic', 'other']

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold text-primary mb-6">Fresh Produce</h1>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <input
          className="input max-w-xs"
          placeholder="Search products..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="flex gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSearchParams(cat ? { category: cat } : {})}
              className={`px-4 py-1.5 rounded-full text-sm font-medium border transition ${category === cat ? 'bg-primary text-white border-primary' : 'border-gray-300 text-gray-600 hover:border-primary'}`}
            >
              {cat || 'All'}
            </button>
          ))}
          <button
            onClick={() => setSearchParams({ isOrganic: 'true' })}
            className={`px-4 py-1.5 rounded-full text-sm font-medium border transition ${isOrganic === 'true' ? 'bg-secondary text-white border-secondary' : 'border-gray-300 text-gray-600 hover:border-secondary'}`}
          >
            🌱 Organic
          </button>
        </div>
      </div>

      {loading ? (
        <p className="text-center text-gray-500 py-20">Loading products...</p>
      ) : products.length === 0 ? (
        <p className="text-center text-gray-500 py-20">No products found.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map(p => (
            <Link key={p._id} to={`/products/${p._id}`} className="card hover:shadow-xl hover:-translate-y-1 transition-all">
              <div className="h-36 bg-light rounded-xl flex items-center justify-center text-5xl mb-3">
                {p.category === 'vegetables' ? '🥦' : p.category === 'fruits' ? '🍎' : p.category === 'dairy' ? '🥛' : '🌾'}
              </div>
              {p.isOrganic && <span className="badge-organic mb-1 inline-block">Organic</span>}
              <h3 className="font-bold text-gray-800">{p.name}</h3>
              <p className="text-sm text-gray-500 mt-0.5">{p.farmer?.name} · {p.farmer?.farmLocation}</p>
              <div className="flex justify-between items-center mt-3">
                <span className="font-bold text-primary text-lg">₹{p.price}/{p.unit}</span>
                <span className="text-xs text-gray-400">{p.availableQuantity}{p.unit} left</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
