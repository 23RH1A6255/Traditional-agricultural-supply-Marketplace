import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'

export default function FarmerDashboard() {
  const { user } = useAuth()
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [form, setForm] = useState({ name: '', category: 'vegetables', price: '', unit: 'kg', availableQuantity: '', isOrganic: false, description: '' })
  const [tab, setTab] = useState('products')

  useEffect(() => {
    api.get(`/products?farmer=${user._id}`).then(r => setProducts(r.data))
    api.get('/orders/farmer').then(r => setOrders(r.data))
  }, [])

  const addProduct = async (e) => {
    e.preventDefault()
    const { data } = await api.post('/products', form)
    setProducts([...products, data])
    setForm({ name: '', category: 'vegetables', price: '', unit: 'kg', availableQuantity: '', isOrganic: false, description: '' })
  }

  const deleteProduct = async (id) => {
    await api.delete(`/products/${id}`)
    setProducts(products.filter(p => p._id !== id))
  }

  const updateOrderStatus = async (id, status) => {
    await api.put(`/orders/${id}/status`, { status })
    setOrders(orders.map(o => o._id === id ? { ...o, status } : o))
  }

  const statusColor = { pending: 'bg-yellow-100 text-yellow-700', confirmed: 'bg-blue-100 text-blue-700', dispatched: 'bg-purple-100 text-purple-700', delivered: 'bg-green-100 text-green-700', cancelled: 'bg-red-100 text-red-700' }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <div className="flex items-center gap-3 mb-6">
        <div className="text-4xl">🚜</div>
        <div>
          <h1 className="text-2xl font-bold text-primary">Welcome, {user.name}</h1>
          <p className="text-gray-500 text-sm">{user.farmLocation} · {user.farmingMethod}</p>
          {!user.isVerified && <span className="text-xs text-yellow-600 bg-yellow-100 px-2 py-0.5 rounded-full">⏳ Pending Approval</span>}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {['products', 'add-product', 'orders'].map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-lg text-sm font-medium transition ${tab === t ? 'bg-primary text-white' : 'bg-white text-gray-600 border hover:border-primary'}`}>
            {t === 'products' ? '📦 My Products' : t === 'add-product' ? '➕ Add Product' : '📋 Orders'}
          </button>
        ))}
      </div>

      {/* My Products */}
      {tab === 'products' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {products.length === 0 && <p className="text-gray-400">No products yet. Add one!</p>}
          {products.map(p => (
            <div key={p._id} className="card flex justify-between items-start">
              <div>
                <h3 className="font-bold">{p.name}</h3>
                <p className="text-sm text-gray-500">₹{p.price}/{p.unit} · {p.availableQuantity}{p.unit} available</p>
                {p.isOrganic && <span className="badge-organic">Organic</span>}
              </div>
              <button onClick={() => deleteProduct(p._id)} className="text-red-400 hover:text-red-600 text-sm">Delete</button>
            </div>
          ))}
        </div>
      )}

      {/* Add Product */}
      {tab === 'add-product' && (
        <div className="card max-w-lg">
          <h2 className="font-bold text-lg mb-4 text-primary">Add New Product</h2>
          <form onSubmit={addProduct} className="space-y-3">
            <input className="input" placeholder="Product Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
            <select className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
              {['vegetables', 'fruits', 'dairy', 'grains', 'other'].map(c => <option key={c}>{c}</option>)}
            </select>
            <div className="flex gap-3">
              <input className="input" type="number" placeholder="Price (₹)" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} required />
              <input className="input" placeholder="Unit (kg/litre)" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} />
            </div>
            <input className="input" type="number" placeholder="Quantity Available" value={form.availableQuantity} onChange={e => setForm({ ...form, availableQuantity: e.target.value })} required />
            <textarea className="input" placeholder="Description" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form.isOrganic} onChange={e => setForm({ ...form, isOrganic: e.target.checked })} />
              Organic product
            </label>
            <button type="submit" className="btn-primary w-full">Add Product</button>
          </form>
        </div>
      )}

      {/* Orders */}
      {tab === 'orders' && (
        <div className="space-y-4">
          {orders.length === 0 && <p className="text-gray-400">No orders yet.</p>}
          {orders.map(o => (
            <div key={o._id} className="card">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold">Order #{o._id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm text-gray-500">{o.consumer?.name} · {o.deliveryAddress}</p>
                </div>
                <span className={`badge-status ${statusColor[o.status]}`}>{o.status}</span>
              </div>
              <div className="flex gap-2 mt-3 flex-wrap">
                {['confirmed', 'dispatched', 'delivered', 'cancelled'].map(s => (
                  <button key={s} onClick={() => updateOrderStatus(o._id, s)} className="text-xs px-3 py-1 rounded-lg border border-gray-300 hover:border-primary transition">
                    Mark {s}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
