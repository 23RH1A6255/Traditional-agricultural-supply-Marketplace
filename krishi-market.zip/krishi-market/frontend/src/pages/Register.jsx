import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'

export default function Register() {
  const [params] = useSearchParams()
  const [form, setForm] = useState({
    name: '', email: '', password: '',
    role: params.get('role') || 'consumer',
    farmLocation: '', cropTypes: '', farmingMethod: 'conventional', phone: '', address: ''
  })
  const [error, setError] = useState('')
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const payload = { ...form, cropTypes: form.cropTypes ? form.cropTypes.split(',').map(s => s.trim()) : [] }
      const { data } = await api.post('/auth/register', payload)
      login(data)
      if (data.role === 'farmer') navigate('/dashboard/farmer')
      else navigate('/products')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-light px-4 py-10">
      <div className="card w-full max-w-md">
        <h2 className="text-3xl font-bold text-primary mb-2 text-center">Create Account</h2>
        <p className="text-center text-gray-500 mb-6 text-sm">Join Krishi Market 🌾</p>
        {error && <p className="text-red-500 text-sm mb-4 text-center">{error}</p>}

        {/* Role Toggle */}
        <div className="flex rounded-xl overflow-hidden border border-gray-200 mb-6">
          {['consumer', 'farmer'].map(r => (
            <button
              key={r}
              type="button"
              onClick={() => setForm({ ...form, role: r })}
              className={`flex-1 py-2 font-semibold text-sm transition ${form.role === r ? 'bg-primary text-white' : 'bg-white text-gray-500'}`}
            >
              {r === 'consumer' ? '🛒 Consumer' : '🚜 Farmer'}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input className="input" placeholder="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          <input className="input" type="email" placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          <input className="input" type="password" placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required />
          <input className="input" placeholder="Phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />

          {form.role === 'farmer' ? (
            <>
              <input className="input" placeholder="Farm Location (e.g. Pune, Maharashtra)" value={form.farmLocation} onChange={e => setForm({ ...form, farmLocation: e.target.value })} />
              <input className="input" placeholder="Crop Types (comma separated)" value={form.cropTypes} onChange={e => setForm({ ...form, cropTypes: e.target.value })} />
              <select className="input" value={form.farmingMethod} onChange={e => setForm({ ...form, farmingMethod: e.target.value })}>
                <option value="conventional">Conventional</option>
                <option value="organic">Organic</option>
                <option value="mixed">Mixed</option>
              </select>
            </>
          ) : (
            <input className="input" placeholder="Delivery Address" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
          )}

          <button type="submit" className="btn-primary w-full py-3 text-lg">Register</button>
        </form>
        <p className="text-center text-sm mt-4 text-gray-600">
          Already have an account? <Link to="/login" className="text-primary font-semibold">Login</Link>
        </p>
      </div>
    </div>
  )
}
